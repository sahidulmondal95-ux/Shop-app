package com.ishaq.shopbilling;
import android.content.*;import android.database.sqlite.*;import android.database.Cursor;
public class DB extends SQLiteOpenHelper{
 public DB(Context c){super(c,"ishaq.db",null,1);} public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,category TEXT,buy REAL,sell REAL,stock INTEGER,minstock INTEGER)");d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice TEXT,date INTEGER,total REAL,payment TEXT,changeAmt REAL)");}
 public void onUpgrade(SQLiteDatabase d,int a,int b){d.execSQL("DROP TABLE IF EXISTS products");d.execSQL("DROP TABLE IF EXISTS sales");onCreate(d);}
 public Cursor products(){return getReadableDatabase().rawQuery("SELECT * FROM products ORDER BY name",null);}
 public long addProduct(String n,String c,double buy,double sell,int st,int min){ContentValues v=new ContentValues();v.put("name",n);v.put("category",c);v.put("buy",buy);v.put("sell",sell);v.put("stock",st);v.put("minstock",min);return getWritableDatabase().insert("products",null,v);}
 public long sale(String inv,double total,String pay,double ch){ContentValues v=new ContentValues();v.put("invoice",inv);v.put("date",System.currentTimeMillis());v.put("total",total);v.put("payment",pay);v.put("changeAmt",ch);return getWritableDatabase().insert("sales",null,v);}
}
