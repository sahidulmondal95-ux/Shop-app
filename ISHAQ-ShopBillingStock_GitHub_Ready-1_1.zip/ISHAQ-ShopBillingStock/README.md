# ISHAQ (ইশাক) — Shop Billing & Stock

GitHub/AppStudio-ready Android Studio project.

## Features
- ISHAQ logo and branding (Since 2026)
- Product & stock database (SQLite, offline)
- Four categories: Stationery, Personal Care, Accessories, Baby Care
- New bill with Cash / UPI / Card
- Invoice/receipt screen with invoice number, date, items, total, payment and change
- Sales history and daily sales total
- Low-stock list

## Build
Use a recent Android Studio. This project uses Android Gradle Plugin 8.6.1, Gradle 8.7 and compile/target SDK 35. AGP 8.6 requires Gradle 8.7 and JDK 17. See Android Developers compatibility documentation.

## Import to AppStudio
Push this entire folder to a public GitHub repository, then use AppStudio → Import from GitHub and search for the repository name.
